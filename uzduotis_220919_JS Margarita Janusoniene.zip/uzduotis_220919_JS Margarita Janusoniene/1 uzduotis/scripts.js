//1.1 Parašyti komandą kuri gražins automobilius, kurie turi parametrą "Miles_per_Gallon" ;
console.log(cars.filter((car) => {
    return car.Miles_per_Gallon
}));


//1.2. Parašyti komandą kuri gražins automobilius, kurie neturi "Miles_per_Gallon" ;
console.log(cars.filter((car) => {
    return !car.Miles_per_Gallon
}));


//1.3  Parašyti komandą kuri gražins automobilius, kurie turi parametrą 8 "Cylinders" ir "Miles_per_Gallon" parametras didesnis arba lygus 15.
console.log(cars.filter((car) => {
    return car.Miles_per_Gallon >= 15 && car.Cylinders === 8
}));


//1.4  Parašyti komandą kuri gražins automobilius su pridėtu papildomu laiku ojekte, kuris vadinasi "Kilowatts", kuris yra lygus "Horsepower" * 0.7457;
console.log(cars.map((car) => {    return {
    ...car,
    Kilowatts: car.Horsepower * 0.7457,
}

}));


//1.5  Parašyti komandą kuri gražins automobilius išrikiuotus pagal "Weight_in_lbs" didėjančia tvarka.
const sortByWeight = cars.sort((a, b) => {
    return a.Weight_in_lbs - b.Weight_in_lbs;
});
console.log(sortByWeight);

//1.6 Parašyti komandą kuri gražins true arba false reikšmę tikrinant ar visi automobiliai yra pagaminti "USA".

const isEveryCarFromUsa = cars.every((cars) => {
    cars.Origin === "USA"
});
console.log(isEveryCarFromUsa);